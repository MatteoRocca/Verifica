const o = require('./verifica');

test('Offusca', () => {
    expect(o.offusca("CIAO")).toBe("C140");
    expect(o.offusca("BOTTE")).toBe("80773");
});

test('Calcola', () => {
    expect('sin(x) + 1', 1.5).toBeClosedTo(1.9974949866040546);
});